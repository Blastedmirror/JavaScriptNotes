function sayHello() {
    console.log('Hello')
  }
setInterval(sayHello, 1000) // it prints hello in every second, 1000ms is 1s

function sayHelloWord() {
    console.log('Hello World')
}
setTimeout(sayHelloWord, 2000) // it prints hello after it waits for 2 seconds.
  