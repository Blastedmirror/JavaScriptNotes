//String to int
// parseInt()
// Number()
// Plus sign(+)
let num = '10'
let bumInt
numInt = parseInt(num)
numInt = Number(num)
numInt = +num

//String to Float
// parseFloat()
// Number()
// Plus sign(+)
num = '9.41'
let numFloat
numFloat = parseInt(num)
numFloat = Number(num)
numFloat = +num